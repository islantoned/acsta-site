/**
 * ACSTA Subscribe → Google Sheet
 * ------------------------------------------------------------
 * 1. Open your Google Sheet. Row 1 headers: Timestamp | Name | Email | Role | Source
 * 2. Extensions → Apps Script. Delete the sample code, paste this file, Save.
 * 3. Deploy → New deployment → Type: Web app
 *      Execute as: Me   |   Who has access: Anyone
 * 4. Copy the Web app URL and paste it into Admin → Subscribe Form → "Google Apps Script Web App URL".
 * No API keys or passwords live in the website code — this URL is the only connection.
 */

var SHEET_NAME = "Sheet1"; // change if your tab is named differently

function doPost(e) {
  try {
    var p = e.parameter || {};
    var email = String(p.email || "").trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return respond({ ok: false, error: "invalid email" });

    var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
    var lock = LockService.getScriptLock();
    lock.waitLock(5000);

    // De-duplicate on email (case-insensitive)
    var emails = sheet.getRange(2, 3, Math.max(sheet.getLastRow() - 1, 1), 1).getValues().map(function (r) { return String(r[0]).toLowerCase(); });
    if (emails.indexOf(email.toLowerCase()) === -1) {
      sheet.appendRow([new Date(), String(p.name || "").slice(0, 100), email.slice(0, 200), String(p.role || "").slice(0, 60), String(p.source || "").slice(0, 100)]);
    }
    lock.releaseLock();
    return respond({ ok: true });
  } catch (err) {
    return respond({ ok: false, error: String(err) });
  }
}

function doGet() { return respond({ ok: true, service: "ACSTA subscribe" }); }

function respond(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
