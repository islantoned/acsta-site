# ACSTA Website

Static site — no build step. Every word and image on the homepage lives in `content/homepage.json`
and is edited through the point-and-click admin at `/admin` once the site is on Netlify.

```
index.html            layout (no copy in here)
styles.css            design — colors, fonts, spacing
app.js                renders content/homepage.json into the layout
content/homepage.json ALL homepage words, prices, links, image paths  ← the only file you edit
images/uploads/       images uploaded through the admin land here
admin/                Decap CMS (the editor) — index.html + config.yml
scripts/              Google Apps Script for the subscribe form
netlify.toml          hosting + security headers
```

## Going live on Netlify (about 15 minutes, one time)

1. Put this folder in a GitHub repo (branch `main`).
2. netlify.com → **Add new site → Import an existing project** → pick the repo. Build command: *(none)*. Publish directory: `.`
3. Netlify → **Site configuration → Identity → Enable Identity**.
   - Registration: **Invite only**.
   - Services → **Enable Git Gateway**.
4. Identity → **Invite users** → your email. Accept the invite, set a password.
5. Open `https://YOUR-SITE.netlify.app/admin/` → log in → edit text, upload images, click **Publish**.
   Every publish commits to the repo and the site updates in about a minute.
6. Domain: **Domain management → Add custom domain**. HTTPS is issued automatically.

## Subscribe form → Google Sheet

Follow the steps at the top of `scripts/google-sheet-apps-script.gs`, then paste the Web app URL into
Admin → **Subscribe Form → Google Apps Script Web App URL**. Until it's set, the form shows a
"not connected yet" message instead of pretending to work.

Spam protection: hidden honeypot field + 3-second time trap in the browser, email validation and
de-duplication in the Apps Script. No credentials of any kind are in the site code.

## Changing the design

`styles.css`, top block (`:root`). `--sun` is marked PLACEHOLDER until the original yellow hex is confirmed.
